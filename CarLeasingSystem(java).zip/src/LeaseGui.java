
public class LeaseGui {

	String Name;
	String BrandModel;
	String Duration;
	
	
	public LeaseGui(String Name, String BrandModel, String Duration) 
	{
		this.BrandModel=BrandModel;
		this.Name=Name;
		this.Duration=Duration;
	}

}
