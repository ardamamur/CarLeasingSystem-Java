
public class ShortTermLease extends LeaseGet {

	
	public ShortTermLease(int CarModelYear) {
		super(CarModelYear);
		
	}
	
	@Override
	public double totalPrice(int LeaseEnd, int LeaseStart, int monthlycost)
	{
		return super.totalPrice(LeaseEnd, LeaseStart, monthlycost)/20;
	}
	
	public void display(int year)
	{

		System.out.println("Lease of " + cartype + " " + car.carmodel+ " for the " + car.CarModelYear + " starts at " + LeaseStart + ". days" + " end at " + LeaseEnd + ". days" + " with cost " + totalPrice(LeaseEnd, LeaseStart, monthlycost) + "$"
				);
	}
	
	public double CalculateInsurance()
	{
		double result_�ns=0;
		result_�ns = totalPrice(LeaseEnd, LeaseStart, monthlycost)*15/100;
		return result_�ns;
		
		
	}

}
