
public interface Insurance {
	
	double CalculateInsurance();
	
}
