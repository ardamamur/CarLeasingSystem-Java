import java.util.Scanner;

import java.util.*;

enum Type
{
	Sedan, Hatchback, Van, Convertible;
}

public class LeaseGet implements Insurance, Comparable<LeaseGet> {
	Scanner xScanner= new Scanner(System.in);
	int LeaseEnd;
	int LeaseStart;
	int monthlycost;
	String carbrand;
	CarClass car;
	Type cartype;
	
	
	
	public LeaseGet() {
	
		car = new CarClass();
		String ch;
		System.out.println("Hire Car Type: \nPlease Type 'S' for Sedan , 'H' for hatchback and 'V' for Van and 'C' for Convertible");
		ch = xScanner.nextLine();
		
		if(ch.equalsIgnoreCase("S"))
		{
			cartype=Type.Sedan;
		}
		
		else if (ch.equalsIgnoreCase("H"))
		{
			cartype=Type.Hatchback;
		}
		
		else if(ch.equalsIgnoreCase("V"))
		{
			cartype=Type.Van;
		}
		
		else if(ch.equalsIgnoreCase("C"))
		{
			cartype=Type.Convertible;
		}
		
		
		System.out.printf("%s\n","Enter a Lease Start: ");
		LeaseStart=(int) xScanner.nextInt();
		
		System.out.printf("%s\n","Enter a Lease End: ");
		LeaseEnd=(int) xScanner.nextInt();
		
		
	}
	
	public LeaseGet(int CarModelYear)
	{
		
		
		this();		
		this.car.CarModelYear=CarModelYear;
		//carbrand=car.carbrand;
		

	
	}
	
	public int compareTo(LeaseGet cr)
	{
		
		if(cr.car.CarModelYear==0)
		{
			return 0;
		}
		else if (car.CarModelYear>cr.car.CarModelYear)
		{
			return 1;
		}
		
		else 
			return -1;
		
	
	}
	
	
	
	
	
	
	public int CalculateCost(int CarModelYear)
	{
		if (CarModelYear <= 2000)
		{
			monthlycost=500;
		}
		else if(CarModelYear > 2000 && CarModelYear <= 2005)
		{
			monthlycost=1000;
		}
		else if(CarModelYear > 2005 && CarModelYear <= 2010)
		{
			monthlycost=1500;
		}
		else if (CarModelYear > 2010 && CarModelYear <= 2015)
		{
			monthlycost=2000;
		}
		else if (CarModelYear > 2015)
		{
			monthlycost=2500;
		}
		
		return monthlycost;
		
	}
	
	
	public double totalPrice(int LeaseEnd, int LeaseStart, int monthlycost)
	{
		double total=0;
		if(LeaseEnd<LeaseStart)
		{
			total=(LeaseEnd+LeaseStart+1)*monthlycost;
		}
	
		if(LeaseEnd>LeaseStart)
		{
			total=(LeaseEnd-LeaseStart+1)*monthlycost;
		}
		
		return total;
		
	}
	
	public void display()
	{
		System.out.println("Lease of " + car.carmodel+ " starts at " + LeaseStart + ". Months" + " end at " + LeaseEnd + ". Months" + " with cost " + totalPrice(LeaseEnd, LeaseStart, monthlycost) + "$"
				);
		
		
	}
	
	public void display(int year)
	{

		System.out.println("Lease of " + cartype + " " + car.carmodel+ " for the " + car.CarModelYear + " starts at " + LeaseStart + ". Months" + " end at " + LeaseEnd + ". Months" + " with cost " + totalPrice(LeaseEnd, LeaseStart, monthlycost) + "$"
				);
	}
	
	public void displayType()
	{
		System.out.println(cartype + " was leased");
	}
	
	
	
	
	@Override
	public double CalculateInsurance()
	{
		double result_�ns=0;
		result_�ns = totalPrice(LeaseEnd, LeaseStart, monthlycost)*25/100;
		return result_�ns;
		
		
	}
	
	
	
	
	

}
