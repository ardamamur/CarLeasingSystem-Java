import java.util.Scanner;
public class CarClass implements Insurance {
	String carmodel;
	String carbrand;
	int IndexSpace=0;
	
	int CarModelYear;
	Scanner myScanner= new Scanner(System.in);
	
	public CarClass()
	{
	
		System.out.print("Enter a Brand and Model:\n");
		carmodel=myScanner.nextLine();
		
	
	}
	
	
	@Override
	public double CalculateInsurance()
	{
		double result_�ns=0;
		result_�ns = (CarModelYear - 2000)*100;
		return result_�ns;
	}
}
