
import java.util.*;
import java.util.List;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class LeaseDrive {
	

	

	public static void main(String[] args) {
		/*LeaseGet[] LeasePlan = new LeaseGet[10];
		ShortTermLease[] ShortPlan = new ShortTermLease[10];
		LongTermLease[] LongPlan = new LongTermLease[10];
		*/
		List <LeaseGet> LeaseList =new ArrayList <LeaseGet> ();
		List <ShortTermLease> ShortList = new ArrayList <ShortTermLease> ();
		List <LongTermLease> LongList = new ArrayList <LongTermLease> ();
		List <CarClass> CarList = new ArrayList <CarClass> ();
		List <LeaseGet> CarYearList = new ArrayList <LeaseGet> ();
		List <LeaseGui> LeaseGuiList = new ArrayList <LeaseGui> ();
		
		
		
		
		Map <String, String> myMap = new HashMap <String, String> ();
		
		Scanner yScanner= new Scanner(System.in);
		int choose=0;
		int x=0;
		int y=0;
		int z=0;
		int c=0;
		int w=0;
		int select=0;
		int year=0;
		
		String username="";
		String password="";
		
		
		JFrame frame;
		JButton Lease;
		JButton Display;
		JButton Exit;
		JLabel label;
		
		frame = new JFrame ("The Leasing System");
		
		frame.setLayout(null);
		
		
		label = new JLabel("Car Leasing System");
		label.setFont(new Font("Serif", Font.BOLD,20));
		label.setBounds(100,10,200,50);
		
		frame.add(label);
		
		
		
		Lease = new JButton("Lease a Car");
		Display = new JButton("Display all Leases");
		Exit = new JButton ("Exit");
		
		Lease.setBounds(100, 100, 200, 50);
		Display.setBounds(100, 200, 200, 50);
		Exit.setBounds(100, 300, 200, 50);
		
		frame.add(Lease);
		frame.add(Display);
		frame.add(Exit);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400,500);
		frame.setVisible(true);
		
		
		
		JFrame frameLease;
		JFrame frameDisplay;
		JLabel labelLease;
		JTextField DriverName;
		JLabel txtname;
		JLabel txtcar;
		JTextField CarBrand;
		JLabel txtduration;
		JTextField LeaseDuration;
		JButton Save;
		JButton Cancel;
		
		
		frameLease = new JFrame("");
		frameLease.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameLease.setSize(400,500);	

		
		labelLease = new JLabel("Enter Lease Information");
		labelLease.setFont(new Font("Ariel", Font.BOLD,20));
		labelLease.setBounds(100,10,200,100);
	
		
		txtname = new JLabel ("Driver Name:");
		txtname.setBounds(10,83, 100, 50);
		DriverName = new JTextField("");
		DriverName.setBounds(90, 100, 150, 20);
		
		
		txtcar = new JLabel ("Car Brand and Model:");
		txtcar.setBounds(10, 150, 300, 50);
		CarBrand = new JTextField("");
		CarBrand.setBounds(140, 165, 200, 20);
		
		txtduration = new JLabel ("Lease Duration:");
		txtduration.setBounds(10,200, 200, 50);
		LeaseDuration = new JTextField ("");
		LeaseDuration.setBounds(110, 220, 100, 20);
		
		Save = new JButton("Save");
		Cancel = new JButton("Cancel");
		
		Save.setBounds(180, 400, 90, 45);
		Cancel.setBounds(290, 400, 90, 45);
		
		
		frameLease.add(labelLease);

		frameLease.add(DriverName);
		frameLease.add(txtname);

		frameLease.add(CarBrand);
		frameLease.add(txtcar);
		
		frameLease.add(LeaseDuration);
		frameLease.add(txtduration);
		
		frameLease.add(Save);
		frameLease.add(Cancel);
		
		frameLease.setLayout(null);

		
		
		class HandlerClass implements ActionListener
		{
			
			@Override
			public void actionPerformed(ActionEvent event)
			{
				String DisplayS = "";
				if(event.getSource().equals(Lease))
				{
					DriverName.setText(" ");
					CarBrand.setText(" ");
					LeaseDuration.setText(" ");
					
					frame.setVisible(false);
					frameLease.setVisible(true);
					
					
				}	
				if(event.getSource().equals(Save))
				{
					String Name = DriverName.getText();
					String Brand = CarBrand.getText();
					String Duration = LeaseDuration.getText();
					LeaseGuiList.add(new LeaseGui(Name,Brand,Duration));
					frameLease.setVisible(false);
					frame.setVisible(true);
					
				}
				if(event.getSource().equals(Cancel))
				{
					frame.setVisible(true);
					frameLease.setVisible(false);
				}
				
				if(event.getSource().equals(Display))
				{
					frameLease.setVisible(false);
					frame.setVisible(true);
					
					for (int index=0; index<LeaseGuiList.size(); index++)
					{
						DisplayS += ("Lease#"+index + "\n" + LeaseGuiList.get(index).Name + "\n" +
							LeaseGuiList.get(index).BrandModel + "\n" + LeaseGuiList.get(index).Duration + "\n");
					}
					
					JOptionPane.showMessageDialog(null, String.format("%s", DisplayS));
					
				}
				
				
				if(event.getSource().equals(Exit))
				{
					frameLease.setVisible(false);
					frame.setVisible(false);
				}
				
				
			}
			
			
			
		}

		HandlerClass handler = new HandlerClass();
		Lease.addActionListener(handler);
		Display.addActionListener(handler);
		Exit.addActionListener(handler);
		Cancel.addActionListener(handler);
		Save.addActionListener(handler);
		
		
		
		
		while(true) 
		{
			System.out.println("MENU");
			
			System.out.println("1.Create a new Lease with model Year \n2.Display all Leases \n3.Calculate Total Insurance of Leasing Company \n4.Display all username of clients \n0.Exit\n");
			choose=yScanner.nextInt();
			
		
			
			
			if(choose==1)
			{
				
			
				int flagu=0;
				int flagp=0;
				
				
				while(flagu==0)
				{
					System.out.println("Enter a username:");
					username = yScanner.next();
					
					
					
					if(username.length()<8)
					{
						System.out.println("Username must be at least eight characters!");
						
					}
					
					else if(Character.isDigit(username.charAt(username.length()-1)))
					{
						System.out.println("Username can not be end with digit!");
					
					}
					
					else 
					{
						flagu=1;
						break;
					}
					
				}
				
				while (true)
				{
				
				
					System.out.println("Enter a password");
					password = yScanner.next();
					
					char a;
					for(int l=0;l < password.length(); l++) 
					{
				        a = password.charAt(l);
				        if (!Character.isUpperCase(a)) 
				        {
				        	flagp=0;
				        }
				        else if(Character.isUpperCase(a))
				        {
				        	flagp=1;
				        	break;
				        }
				        
					}
					
					if(flagp==0)
					{
						System.out.println("The password must contains uppercase letters");
					}
					else
						break;
						
				
				}
				
				
				myMap.put(username, password);
				System.out.println("You have successfully registered");
					
			
				   
			
				
				
				        
					
				
				
				
				
				
				System.out.println("1.Create Monthly Lease (Lease) \n2.Create a ShortTermLease \n3.Create LongTermLease");
				select=yScanner.nextInt();
				
				
				if(select==1)
				{
					boolean loop = true;
					
					
					do
					{
						try
						{
							System.out.println("Enter a Model Year:");
							year=(int) yScanner.nextInt();
							
							loop = false;
						}	
						catch (InputMismatchException inputMisMatchException)
						{
							System.err.printf("Exception: %s\n", inputMisMatchException);
							yScanner.nextLine();
							System.out.printf("Please enter the model year correctly!\n");
							
						}
						
					}while(loop);
					
					
					
					
					
					LeaseGet LeaseTerm = new LeaseGet (year);
					LeaseList.add(LeaseTerm);
					CarYearList.add(LeaseTerm);
					
					
					CarClass Car = LeaseList.get(x).car;
					CarList.add(c,Car);
					c++;
			
					LeaseList.get(x).CalculateCost(year);
					
					
					LeaseList.get(x).displayType();
					x++;
					w++;
					
					
					
				}
				else if(select==2)
				{
					
		
					
					boolean loop2 = true;
					
					
					do
					{
						try
						{
							System.out.println("Enter a Model Year:");
							year=(int) yScanner.nextInt();
							
							loop2 = false;
						}	
						catch (InputMismatchException inputMisMatchException)
						{
							System.err.printf("Exception: %s\n", inputMisMatchException);
							yScanner.nextLine();
							System.out.printf("Please enter the model year correctly!\n");
							
						}
						
					}while(loop2);
			
					
					ShortTermLease ShortTerm = new ShortTermLease (year);
					ShortList.add(ShortTerm);
					CarYearList.add(ShortTerm);
			
					CarClass Car = ShortList.get(y).car;
					CarList.add(c,Car);
					c++;		
					
					
					ShortList.get(y).CalculateCost(year);
					
					ShortList.get(y).displayType();
					
					y++;
					w++;
					
					
				}
				else if(select==3)
				{
					
					boolean loop3 = true;
					
					
					do
					{
						try
						{
							System.out.println("Enter a Model Year:");
							year=(int) yScanner.nextInt();
							
							loop3 = false;
						}	
						catch (InputMismatchException inputMisMatchException)
						{
							System.err.printf("Exception: %s\n", inputMisMatchException);
							yScanner.nextLine();
							System.out.printf("Please enter the model year correctly!\n");
							
						}
						
					}while(loop3);
					
					
					
					
					LongTermLease LongTerm = new LongTermLease (year);
					LongList.add(LongTerm);
					CarYearList.add(LongTerm);
			
					
					CarClass Car = LongList.get(z).car;
					CarList.add(c,Car);
					c++;
					
					
					LongList.get(z).CalculateCost(year);
					
					LongList.get(z).displayType();
					
					z++;
					w++;
					
					
				}
				else 
				{
					System.out.println("Invalid input");
				}
					
				
				
				System.out.printf("%s\n","Lease created with model year as " + year + " !");
	
				
			}
			
			else if(choose==2) 
			{

				int response=0;
				System.out.println("1.Ascending Order \n2.Descending Order");
				response=(int) yScanner.nextInt();
				
				
				
				/*for(int k=0; k<x; k++)
				{
					//LeasePlan[k].display(year);
					LeaseList.get(k).display(year);
				}
				
	
				for(int k=0; k<y; k++)
				{
					//ShortPlan[k].display(year);
					ShortList.get(k).display(year);
				}
				
			
				for(int k=0; k<z; k++)
				{
					//LongPlan[k].display(year);
					LongList.get(k).display(year);
				}
				*/
				
				Collections.sort(CarYearList);
				
				if(response==1)
				{
					for(int k=0; k<w; k++)
					{
						CarYearList.get(k).display(year);
					}
				
				}
				
				else if(response==2)
				{
					Collections.reverse(CarYearList);
					for(int k=0; k<w; k++)
					{
						CarYearList.get(k).display(year);
					}
					
				}
				
		
			}

			else if(choose==3)
			{
				double res_�ns=0;
				for (int t=0; t<x; t++)
				{
				
					res_�ns = res_�ns + LeaseList.get(t).CalculateInsurance();
	
				}
				
				for (int t=0; t<y; t++)
				{
					res_�ns = res_�ns + ShortList.get(t).CalculateInsurance();
				}
				
				for (int t=0; t<z; t++)
				{
					res_�ns = res_�ns + LongList.get(t).CalculateInsurance();
				}
				
				
				for (int t=0; t<c; t++)
				{
					res_�ns = res_�ns + CarList.get(t).CalculateInsurance();
				}
				
				
				System.out.println("Total insurance spent by company is " + res_�ns);
			
			}
			
			
			else if(choose==4)
			{
				Set <String> keys = myMap.keySet();
				
				for(String key : keys)
				{
					System.out.println( key );
				}
			}
			
			
			
			else if(choose==0)
			{
				break;
			}
	
		}
	}
	
	
}
