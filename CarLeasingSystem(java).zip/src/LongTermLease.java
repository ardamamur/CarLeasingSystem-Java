
public class LongTermLease extends LeaseGet {


	public LongTermLease(int CarModelYear) {
		super(CarModelYear);
	
	}

	@Override
	public double totalPrice(int LeaseEnd, int LeaseStart, int monthlycost)
	{
		return super.totalPrice(LeaseEnd, LeaseStart, monthlycost)*10;
	}
	
	public void display(int year)
	{

		System.out.println("Lease of " + cartype + " " + car.carmodel+ " for the " + car.CarModelYear + " starts at " + LeaseStart + ". years" + " end at " + LeaseEnd + ". years" + " with cost " + totalPrice(LeaseEnd, LeaseStart, monthlycost) + "$"
				);
	}
	
	public double CalculateInsurance()
	{
		double result_�ns=0;
		result_�ns = totalPrice(LeaseEnd, LeaseStart, monthlycost)*35/100;
		return result_�ns;
		
		
	}
	
}
